from fastapi import APIRouter, UploadFile, File, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from typing import List, Dict
import numpy as np
import onnxruntime as ort
import os, time, json

router = APIRouter()

class EmbeddingPayload(BaseModel):
    student_id: str
    session_id: str
    timestamp: float
    embedding: List[float]
    meta: Dict = {}

SCORES = {}
MODEL_PATH = os.path.join(os.path.dirname(__file__), '..', '..', 'model', 'ai_teacher_stub.onnx')

# Load ONNX session once (CPU)
if os.path.exists(MODEL_PATH):
    sess = ort.InferenceSession(MODEL_PATH)
else:
    sess = None

def infer_score(embedding):
    # If ONNX model exists, run it; otherwise do simple heuristic
    if sess is not None:
        inp = np.array(embedding, dtype=np.float32).reshape(1, -1)
        try:
            out = sess.run(None, {sess.get_inputs()[0].name: inp})
            score = float(out[0].squeeze().item())
            return max(0.0, min(1.0, score))
        except Exception as e:
            print('ONNX inference failed', e)
    # fallback heuristic
    v = np.array(embedding, dtype=float)
    mn, mx = v.min(), v.max()
    mean = v.mean()
    return float((mean - mn) / (mx - mn + 1e-8))

@router.post("/embeddings")
async def receive_embedding(payload: EmbeddingPayload):
    score = infer_score(payload.embedding)
    SCORES.setdefault(payload.session_id, {})[payload.student_id] = {
        "score": score,
        "state": "engaged" if score>0.55 else "confused" if score<0.45 else "neutral",
        "timestamp": payload.timestamp,
    }
    return {"ok": True, "score": score}

@router.get("/session/{session_id}/scores")
async def get_scores(session_id: str):
    return SCORES.get(session_id, {})

# Simple websocket manager for pushing updates (MVP)
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: str):
        for connection in list(self.active_connections):
            try:
                await connection.send_text(message)
            except:
                pass

manager = ConnectionManager()

@router.websocket("/ws/scores")
async def websocket_scores(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # ignore messages, send current scores
            await manager.broadcast(json.dumps(SCORES))
    except WebSocketDisconnect:
        manager.disconnect(websocket)
