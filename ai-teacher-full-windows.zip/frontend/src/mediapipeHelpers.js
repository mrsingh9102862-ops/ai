// MediaPipe-based embedding extractor (Face Mesh)
// Uses @mediapipe/face_mesh and @mediapipe/camera_utils.

import { FaceMesh } from '@mediapipe/face_mesh'
import { Camera } from '@mediapipe/camera_utils'

let faceMesh = null
let latestResult = null
let initialized = false

async function ensureFaceMesh(){
  if(initialized) return
  faceMesh = new FaceMesh({
    locateFile: (file) => {
      return `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`
    }
  })

  faceMesh.setOptions({
    maxNumFaces: 1,
    refineLandmarks: true,
    minDetectionConfidence: 0.5,
    minTrackingConfidence: 0.5
  })

  faceMesh.onResults((results) => {
    latestResult = results
  })

  initialized = true
}

function dist(a,b){
  const dx = a.x - b.x
  const dy = a.y - b.y
  const dz = (a.z||0) - (b.z||0)
  return Math.sqrt(dx*dx + dy*dy + dz*dz)
}

function landmarksToEmbedding(landmarks){
  const idx = { leftEye: 33, rightEye: 263, noseTip: 1, mouthLeft: 61, mouthRight: 291 }
  const L = landmarks
  function get(i){ return L[i] || {x:0,y:0,z:0} }
  const le = get(idx.leftEye), re = get(idx.rightEye)
  const ni = get(idx.noseTip)
  const ml = get(idx.mouthLeft), mr = get(idx.mouthRight)
  const eyeDist = dist(le,re)
  const mouthOpenness = dist(ml,mr)
  const headYaw = (le.x - re.x)/(eyeDist+1e-8)
  const emb = [eyeDist, mouthOpenness, headYaw, ni.x, ni.y]
  while(emb.length<20) emb.push(0)
  return emb.slice(0,20)
}

export async function extractEmbedding(videoEl){
  try{
    await ensureFaceMesh()
    latestResult = null
    await faceMesh.send({image: videoEl})
    const start = performance.now()
    while(latestResult === null && performance.now() - start < 200){ await new Promise(r=>setTimeout(r,10)) }
    if(!latestResult || !latestResult.multiFaceLandmarks || latestResult.multiFaceLandmarks.length===0) return null
    const landmarks = latestResult.multiFaceLandmarks[0]
    return landmarksToEmbedding(landmarks)
  }catch(e){ console.error('extractEmbedding error', e); return null }
}
