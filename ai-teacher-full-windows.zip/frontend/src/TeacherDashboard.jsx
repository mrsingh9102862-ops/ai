import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function TeacherDashboard(){
  const [scores, setScores] = useState({})

  useEffect(()=>{
    const interval = setInterval(async ()=>{
      try{
        const res = await axios.get('http://localhost:8000/api/v1/session/class123/scores')
        setScores(res.data)
      }catch(e){ }
    }, 1500)
    return ()=> clearInterval(interval)
  }, [])

  return (
    <div>
      <h3>Teacher Dashboard — Live Scores</h3>
      <div style={{display:'flex', gap:12, flexWrap:'wrap'}}>
        {Object.entries(scores).length===0 && <div>No students yet. Open student clients or run simulator.</div>}
        {Object.entries(scores).map(([sid, data])=> (
          <div key={sid} style={{border:'1px solid #ccc', padding:8, width:160}}>
            <strong>{sid}</strong>
            <div>Score: {(data.score||0).toFixed(2)}</div>
            <div>State: {data.state}</div>
            <button onClick={()=>alert('Ask recap sent to '+sid)}>Ask Recap</button>
          </div>
        ))}
      </div>
    </div>
  )
}
