import React from 'react'
import StudentClient from './StudentClient'
import TeacherDashboard from './TeacherDashboard'

export default function App(){
  const [mode, setMode] = React.useState('student')
  return (
    <div style={{padding:20}}>
      <h2>AI Teacher — Full</h2>
      <div>
        <button onClick={()=>setMode('student')}>Student Client</button>
        <button onClick={()=>setMode('teacher')}>Teacher Dashboard</button>
      </div>
      {mode==='student' ? <StudentClient/> : <TeacherDashboard/>}
    </div>
  )
}
