import React, {useRef, useEffect} from 'react'
import { extractEmbedding } from './mediapipeHelpers'
import axios from 'axios'

export default function StudentClient(){
  const videoRef = useRef(null)
  const studentId = 'student_' + Math.floor(Math.random()*1000)
  const sessionId = 'class123'

  useEffect(()=>{
    async function start(){
      const stream = await navigator.mediaDevices.getUserMedia({video:true, audio:false})
      videoRef.current.srcObject = stream
      videoRef.current.play()

      setInterval(async ()=>{
        const emb = await extractEmbedding(videoRef.current)
        if(!emb) return
        try{
          await axios.post('http://localhost:8000/api/v1/embeddings', {
            student_id: studentId,
            session_id: sessionId,
            timestamp: Date.now()/1000,
            embedding: emb,
            meta: {device: 'web'}
          })
        }catch(e){ console.error(e) }
      }, 2000)
    }
    start()
  }, [])

  return (
    <div>
      <h3>Student Client — {studentId}</h3>
      <video ref={videoRef} width={320} height={240} />
      <p>Consent: By using this demo you consent to local embeddings sent to backend for testing.</p>
    </div>
  )
}
