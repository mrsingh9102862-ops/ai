import numpy as np
import onnxruntime as ort, os

MODEL = os.path.join(os.path.dirname(__file__), 'ai_teacher_stub.onnx')
def infer(emb):
    try:
        sess = ort.InferenceSession(MODEL)
        inp = np.array(emb, dtype=np.float32).reshape(1, -1)
        out = sess.run(None, {sess.get_inputs()[0].name: inp})
        print('ONNX output:', out)
    except Exception as e:
        print('ONNX not usable, fallback heuristic. mean-based score:', float(np.array(emb).mean()))

if __name__ == '__main__':
    emb = np.random.rand(20).tolist()
    infer(emb)
