# AI-Teacher — Full Build (Windows, Full Version A)

This package is a one-click ready project for **AI-Teacher (Full)** targeted for **Windows laptop** development & testing.
It includes **frontend (React + MediaPipe)**, **backend (FastAPI)**, **ONNX model stub**, and **Docker** setup for both **dev** and **prod** modes.

---
## What is included
- frontend/ (React + MediaPipe face embeddings + WebRTC UI)
- backend/ (FastAPI API, model server, WebSocket placeholders)
- model/ (onnx stub and example inference script)
- docker/ (Dockerfiles and docker-compose dev/prod)
- scripts/ (Windows .bat helpers to run without Docker)
- README contains Windows-specific run instructions

## Windows Quick Start (no Docker)
### Prerequisites
- Python 3.10+ (download from python.org) and added to PATH
- Node.js 18+ and npm
- Git (optional)
- VS Code recommended

### Backend (run locally)
1. Open PowerShell or CMD.
2. `cd` into backend folder:
   ```powershell
   cd backend
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```
3. Backend will be available at `http://localhost:8000`.

### Frontend (run locally)
1. Open another terminal, go to frontend:
   ```powershell
   cd frontend
   npm install
   npm run start
   ```
2. Open browser: `http://localhost:3000`
3. Open one Student Client tab (allow camera) and one Teacher Dashboard tab.

### Model (local ONNX inference demo)
- There's a small `model/demo_infer.py` that loads `model/ai_teacher_stub.onnx` and runs a sample embedding.

## Windows Quick Start (with Docker - Dev)
1. Install Docker Desktop for Windows and enable WSL2 backend if prompted.
2. Open PowerShell in project root.
3. Run:
   ```powershell
   docker-compose -f docker/docker-compose.dev.yml up --build
   ```
4. This will build frontend/backend images and mount local folders for hot reload.
5. Frontend: http://localhost:3000, Backend: http://localhost:8000

## Windows Quick Start (Production Docker)
1. Build production images and start:
   ```powershell
   docker-compose -f docker/docker-compose.prod.yml up --build -d
   ```
2. Frontend served via Nginx on http://localhost, backend proxied on /api.

---
## Notes & Privacy
- This is a demo MVP. Do not use with real student data without consent and proper privacy measures.
- For production deployment, set up HTTPS, authentication, and data storage protections.
